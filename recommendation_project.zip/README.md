
# Recommendation System Project

This project aims to implement a recommendation system like those used by Netflix or Amazon to suggest products or movies. The project involves data collection, preprocessing, model building using collaborative filtering techniques, and evaluation.

## Tools Used
- Python
- scikit-learn
- pandas
- surprise
- Jupyter Notebook

## Project Structure
- `data/`: Contains the dataset.
- `recommendation_system.ipynb`: Jupyter Notebook with the project code and documentation.

## How to Run
1. Clone the repository.
2. Install the required packages: `pip install -r requirements.txt`
3. Open `recommendation_system.ipynb` in Jupyter Notebook.
4. Run the cells sequentially.

## Results
The recommendation system was successfully implemented and evaluated.
